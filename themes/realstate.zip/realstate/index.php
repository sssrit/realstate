<?php
get_header();
get_footer();
?>